    

    <div class='footer-wrap row'>
        <div class='inner-foot col-md-12 col-sm-12 col-xs-12'></div>
        
        <div class='outter-wrap col-md-11 col-md-offset-1'>
            
            <ul class='contact-me col-md-10 col-sm-12 col-xs-12'>
                <li id='name-footer'>CHAD JOHNSON</li>
                <li>SYRACUSE, NY</li>
                <li>PHONE: 315-283-4417</li>
                <li class='web-dev'>WEB DEVELOPMENT</li>
                <li class='environment'> ENVIRONMENTAL SCIENCE AND ENGINEERING</li>
                <li>&#169 ALL RIGHTS RESERVED</li>
            </ul>

        </div>
    </div>

	<?php wp_footer(); ?>
	</body>
</html>