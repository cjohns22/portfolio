<!--// ABOUT ME TAB //-->
<?php get_header(); ?>	
	
	<div id='wpb-slider-wrapper'>
		<?php
		$gallery = get_option('wpb_gallery');
		$slides = new WP_query(array( 
    		'post_type' => 'attachment',
    		'post_status' => 'any',
    		'tax_query' => array(
	            array(
	                'taxonomy' => 'gallery',
	                'terms' => $gallery,
	                'field' => 'term_id',
	                )
        	)
		));
		if ($slides->have_posts()) {
			$num_slides = $slides->post_count; $first = true; ?>
			<section id="carousel-media" class="carousel row slide" data-ride="carousel" data-interval='5000'>
		        <ol class="carousel-indicators"><?php
		            for ($i=0; $i < $num_slides; $i++) { ?>
		                <li data-target="#carousel-media" data-slide-to="<?php echo $i; ?>" class="<?php echo $i==0 ? 'active' : ''; ?>"></li><?php
		            } ?>
    			</ol><!--/.carousel-indicators-->
       			 <div class="carousel-inner"><?php
		            while ($slides->have_posts()) { $slides->the_post(); 
		                $image_id = get_the_ID();
		                $image_src = wp_get_attachment_image_src($image_id, 'full');?>
		                <div class="item <?php if($first){ echo 'active'; $first=false; } ?>">
		                    <img src="<?php echo $image_src[0]; ?>" alt="<?php echo the_title(); ?>" id='gallery-image'>
		                    <div class="carousel-caption"></div><!--/.carousel-caption-->
		                    <div class='wpb-slider-caption'>
		                    	<h3><?php the_title() ; ?></h3>
		                    	<p><?php the_excerpt(); ?></p>
		                    	
		                    </div>
		               	</div><!--/.item--><?php
		            } ?>
           		 </div><!--/.carousel-inner-->
   			</section><?php 
		} ?>
	</div>

<div id='front-resume'>
	<h3 id="resume" class='sn-wrap col-md-6 col-xs-12 col-sm-10 col-sm-offset-1 col-md-offset-4'>VIEW MY RESUME</h3>
	<span id="toggle-arrow" class="active-arrow glyphicon glyphicon-chevron-up col-xs-12 col-sm-12 col-md-10 col-md-offset-2" aria-hidden="true"></span>
</div>
	
<div class="row" id='resume-wrapper'>
	<div class = "col-md-8 col-xs-12 col-sm-10 col-sm-offset-1 col-md-offset-3" id="resume-wrap">
		<?php $my_query = new WP_Query( 'category_name=PDF&posts_per_page=1' );
		while ( $my_query->have_posts() ) : $my_query->the_post();
			$do_not_duplicate = $post->ID; ?>
				<div> <?php the_content(); ?></div>
		<?php endwhile; ?>
	</div>
</div>

<audio controls="controls">
  Your browser does not support the <code>audio</code> element.
  <source src="<?php echo get_template_directory_uri(); ?>/Static.mp3" type="audio/mpeg">
</audio>

<?php get_footer(); ?>
